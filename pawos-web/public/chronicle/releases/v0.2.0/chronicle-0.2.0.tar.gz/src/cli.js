#!/usr/bin/env node
import readline from "node:readline/promises";
import { stdin, stdout } from "node:process";
import path from "node:path";
import { makePreview } from "./application/preview.js";
import { analyzeGitProject } from "./adapters/git.js";
import { renderLocalReport } from "./report/renderHtml.js";
import { discoverProject } from "./discovery/projectDiscovery.js";
import { suggestedExternalLocations } from "./discovery/externalSources.js";
import { approveExactSource, listGrants } from "./discovery/consent.js";
import { forgetAll, listLocalReports, saveLocalReport, storageStatus } from "./storage/localStore.js";

async function main(args) {
  const command = args[0] || "report";
  if (command === "preview") {
    const preview = await makePreview(process.cwd());
    console.log(JSON.stringify(preview, null, 2));
    return;
  }
  if (command === "scan") {
    const preview = await makePreview(process.cwd());
    console.log(JSON.stringify(preview, null, 2));
    console.log("No source contents have been read. Approve exact external locations to save local grants.");
    const rl = readline.createInterface({ input: stdin, output: stdout });
    try {
      for (const source of suggestedExternalLocations()) {
        const available = preview.externalSources.find(x => x.sourceId === source.sourceId && x.path === source.path)?.available;
        if (!available) continue;
        const answer = (await rl.question(`Approve this exact external path for future local reading? ${source.path} [y/N] `)).trim().toLowerCase();
        if (answer === "y" || answer === "yes") {
          const grant = await approveExactSource(source.path, source.sourceId, preview.project.projectRoot);
          console.log(`Saved local grant ${grant.grantId} for ${grant.sourcePath}. No contents were parsed in this Phase 1 scan.`);
        }
      }
    } finally { rl.close(); }
    console.log(JSON.stringify({ storage: await storageStatus(), grants: (await listGrants()).length }, null, 2));
    return;
  }
  if (command === "report") {
    const root = process.cwd();
    const inventory = await discoverProject(root);
    const projectRoots = [...new Set(inventory.inventory.candidates
      .filter((candidate) => candidate.type === "git_metadata")
      .map((candidate) => path.resolve(root, path.dirname(candidate.relativePath))))];
    if (!projectRoots.length) throw new Error("No Git repositories were found in this folder. Open Git Bash in a project repository or its parent folder and retry.");
    let selected = projectRoots;
    if (projectRoots.length > 1 || path.resolve(projectRoots[0]) !== path.resolve(root)) {
      console.log("Candidate repositories (only marker locations were inspected):");
      projectRoots.forEach((projectRoot, index) => console.log(`  ${index + 1}. ${path.basename(projectRoot)} — ${path.relative(root, projectRoot) || "."}`));
      const rl = readline.createInterface({ input: stdin, output: stdout });
      try {
        const answer = (await rl.question("Choose repositories to analyze (numbers separated by commas, 'all', or Enter to cancel): ")).trim().toLowerCase();
        if (!answer) throw new Error("Scan canceled before reading Git history.");
        if (answer !== "all") {
          const indexes = [...new Set(answer.split(",").map((value) => Number(value.trim()) - 1))];
          if (!indexes.length || indexes.some((index) => !Number.isInteger(index) || index < 0 || index >= projectRoots.length)) throw new Error("Selection was invalid; no repositories were analyzed.");
          selected = indexes.map((index) => projectRoots[index]);
        }
      } finally { rl.close(); }
    }
    for (const projectRoot of selected) {
      const report = await analyzeGitProject(projectRoot);
      const paths = await saveLocalReport(report, renderLocalReport(report));
      console.log(`\nChronicle report created for ${report.project.displayName}.`);
      console.log(`Local HTML: ${paths.htmlPath}`);
      console.log(`Sanitized report data: ${paths.jsonPath}`);
      console.log("Authorship is unclassified from Git metadata. Agent sessions and test/build runs are not included by this release.");
    }
    console.log("\nReports are stored locally. To upload one, sign in to PawOS and use the Chronicle Reports page.");
    return;
  }
  if (command === "reports") { console.log(JSON.stringify(await listLocalReports(), null, 2)); return; }
  if (command === "sources") { console.log(JSON.stringify(await listGrants(), null, 2)); return; }
  if (command === "forget") {
    const rl = readline.createInterface({ input: stdin, output: stdout });
    try { if ((await rl.question("Delete all Chronicle local grants, events, reports, and project identities? [y/N] ")).trim().toLowerCase() === "y") await forgetAll(); }
    finally { rl.close(); }
    return;
  }
  throw new Error(`Unknown command: ${command}. Use report, reports, preview, scan, sources, or forget.`);
}

main(process.argv.slice(2)).catch(error => { console.error(`Chronicle stopped safely: ${error.message}`); process.exitCode = 1; });

import os from "node:os";
import path from "node:path";
import { lstat } from "node:fs/promises";

export function suggestedExternalLocations(env = process.env, platform = process.platform) {
  const home = os.homedir();
  const candidates = [];
  const add = (sourceId, candidate) => { if (candidate) candidates.push({ sourceId, path: path.resolve(candidate) }); };
  add("claude-code", path.join(home, ".claude", "projects"));
  add("codex", path.join(home, ".codex", "sessions"));
  if (platform === "win32") {
    add("cursor", path.join(env.APPDATA || path.join(home, "AppData", "Roaming"), "Cursor", "User", "workspaceStorage"));
  }
  return candidates;
}

export async function inventoryExternalLocations(locations = suggestedExternalLocations()) {
  const out = [];
  for (const item of locations) {
    try {
      const st = await lstat(item.path);
      out.push({ ...item, available: st.isDirectory() && !st.isSymbolicLink(), type: st.isDirectory() && !st.isSymbolicLink() ? "directory_candidate" : "not_usable", contentsInspected: false, approvalRequired: true });
    } catch (error) {
      out.push({ ...item, available: false, type: error.code === "ENOENT" ? "not_present" : "unavailable", contentsInspected: false, approvalRequired: true });
    }
  }
  return out;
}
